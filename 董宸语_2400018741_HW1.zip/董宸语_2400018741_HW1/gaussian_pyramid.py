
# 图像滤波与高斯金字塔，全部手写实现
# 只依赖 numpy 做数组运算，PIL 只用来读写图片
import numpy as np
from PIL import Image
import os


def _corr2(a, b):
    # 单通道的相关运算：核 b 在图 a 上滑窗，对应位置相乘再求和
    # 不翻转核，这正是“相关”和“卷积”的区别所在
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    r1, c1 = a.shape          # 图的高和宽
    kr, kc = b.shape          # 核的高和宽
    pr, pc = kr // 2, kc // 2
    # 四周补零，滑窗时就不用单独判断边界了
    ap = np.zeros((r1 + 2 * pr, c1 + 2 * pc))
    ap[pr:pr + r1, pc:pc + c1] = a
    out = np.zeros_like(a)
    for i in range(r1):
        for j in range(c1):
            win = ap[i:i + kr, j:j + kc]   # 当前窗口
            out[i, j] = (win * b).sum()    # 加权求和
    return out


def cross_correlation_2d(a, b):
    # 彩色图按通道拆开，每个通道各算一次再叠回去
    a = np.asarray(a, dtype=np.float64)
    if a.ndim == 3:
        return np.stack([_corr2(a[:, :, c], b) for c in range(a.shape[2])], axis=2)
    return _corr2(a, b)


def convolve_2d(a, b):
    # 卷积 = 先把核上下、左右翻转 180 度，再做相关
    return cross_correlation_2d(a, np.flip(np.flip(b, 0), 1))


def gaussian_blur_kernel_2d(k, sigma):
    # 生成 k×k 的二维高斯核
    # 思路：先算一维高斯并归一化，再和自己做外积得到二维，最后归一化一次
    if k % 2 == 0:
        raise ValueError("k 必须是奇数")
    if sigma <= 0:
        raise ValueError("sigma 必须为正")
    ax = np.arange(k) - k // 2
    g = np.exp(-(ax ** 2) / (2 * sigma ** 2))
    g = g / g.sum()
    kern = np.outer(g, g)
    kern = kern / kern.sum()
    return kern


def low_pass(a, k, sigma):
    # 低通 = 用高斯核卷积，把高频细节抹掉
    return convolve_2d(a, gaussian_blur_kernel_2d(k, sigma))


def image_subsampling(a):
    # 隔行隔列取样，图缩小一半
    return np.asarray(a)[::2, ::2]


def gaussian_pyramid(a, n, k=5, sigma=1.0):
    # 高斯金字塔：每层先高斯模糊，再缩小一半
    # 返回列表，第 0 层是原图
    a = np.asarray(a, dtype=np.float64)
    lv = [a]
    for _ in range(n - 1):
        a = low_pass(a, k, sigma)
        a = image_subsampling(a)
        lv.append(a)
    return lv


def read_image(path):
    im = Image.open(path)
    return np.asarray(im, dtype=np.float64)


def save_image(arr, path):
    arr = np.asarray(arr)
    if arr.dtype != np.uint8:
        arr = np.clip(arr, 0, 255).astype(np.uint8)
    if arr.ndim == 3 and arr.shape[2] == 4:
        arr = arr[:, :, :3]
    Image.fromarray(arr).save(path)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    src = os.path.join(here, "zebra.jpg")

    a = read_image(src)
    n = 4
    # 第一组：先滤波再下采样（标准做法）
    g = gaussian_pyramid(a, n, k=5, sigma=1.0)
    # 第二组：直接下采样，不做任何平滑，用来对比混叠
    d = [a]
    for _ in range(n - 1):
        d.append(image_subsampling(d[-1]))

    # 把 1/2、1/4、1/8 三个尺度的结果都存下来
    for i in range(1, n):
        save_image(g[i], os.path.join(here, "zebra_gauss_L%d.png" % i))
        save_image(d[i], os.path.join(here, "zebra_direct_L%d.png" % i))

    # 打印每级两种结果的平均差值，差得越多说明混叠越明显
    for i in range(1, n):
        diff = np.abs(g[i] - d[i]).mean()
        print("level %d: shape %s, mean|gauss-direct|=%.2f" %
              (i, str(g[i].shape), diff))


if __name__ == "__main__":
    main()
